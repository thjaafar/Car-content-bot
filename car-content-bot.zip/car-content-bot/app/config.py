import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

    ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")
    ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "")

    PEXELS_API_KEY = os.getenv("PEXELS_API_KEY", "")
    RUNWAY_API_KEY = os.getenv("RUNWAY_API_KEY", "")

    TIKTOK_CLIENT_KEY = os.getenv("TIKTOK_CLIENT_KEY", "")
    TIKTOK_CLIENT_SECRET = os.getenv("TIKTOK_CLIENT_SECRET", "")
    TIKTOK_ACCESS_TOKEN = os.getenv("TIKTOK_ACCESS_TOKEN", "")

    APP_PORT = int(os.getenv("APP_PORT", "8000"))

    STORAGE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "storage")
    VIDEOS_DIR = os.path.join(STORAGE_DIR, "videos")
    AUDIO_DIR = os.path.join(STORAGE_DIR, "audio")
    CLIPS_DIR = os.path.join(STORAGE_DIR, "clips")
    JOBS_FILE = os.path.join(STORAGE_DIR, "jobs.json")


settings = Settings()
