import json
import os
import threading
import uuid
from datetime import datetime, timezone

from app.config import settings

_lock = threading.Lock()


def _ensure_file():
    os.makedirs(settings.STORAGE_DIR, exist_ok=True)
    if not os.path.exists(settings.JOBS_FILE):
        with open(settings.JOBS_FILE, "w") as f:
            json.dump({}, f)


def _read_all() -> dict:
    _ensure_file()
    with open(settings.JOBS_FILE, "r") as f:
        return json.load(f)


def _write_all(data: dict):
    with open(settings.JOBS_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def create_job(topic: str) -> dict:
    with _lock:
        jobs = _read_all()
        job_id = str(uuid.uuid4())[:8]
        job = {
            "id": job_id,
            "topic": topic,
            "status": "queued",  # queued -> scripting -> voicing -> visuals -> assembling -> ready -> posted -> failed
            "script": None,
            "audio_path": None,
            "clip_paths": [],
            "video_path": None,
            "error": None,
            "tiktok_publish_id": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        jobs[job_id] = job
        _write_all(jobs)
        return job


def get_job(job_id: str) -> dict | None:
    jobs = _read_all()
    return jobs.get(job_id)


def list_jobs() -> list[dict]:
    jobs = _read_all()
    return sorted(jobs.values(), key=lambda j: j["created_at"], reverse=True)


def update_job(job_id: str, **fields) -> dict:
    with _lock:
        jobs = _read_all()
        if job_id not in jobs:
            raise KeyError(f"job {job_id} not found")
        jobs[job_id].update(fields)
        jobs[job_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
        _write_all(jobs)
        return jobs[job_id]


def delete_job(job_id: str):
    with _lock:
        jobs = _read_all()
        jobs.pop(job_id, None)
        _write_all(jobs)
