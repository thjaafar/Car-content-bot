"""
Generates a short faceless-narration script for a car-content video.
Uses OpenAI by default; swap in Anthropic if you prefer (see comment below).
"""
import requests
from app.config import settings

SYSTEM_PROMPT = """You write short, punchy TikTok voiceover scripts for a faceless car-content channel.
Rules:
- 100-140 words, meant to be read aloud in 30-45 seconds
- Hook in the first sentence (a surprising fact, bold claim, or question)
- Simple, spoken language - no headers, no emojis, no stage directions
- End with a punchy one-liner, not a call to action like "follow for more"
- Output ONLY the script text, nothing else
"""


def generate_script(topic: str) -> str:
    if not settings.OPENAI_API_KEY:
        # Fallback so the pipeline is runnable end-to-end before you add keys
        return (
            f"Here's something most people don't know about {topic}. "
            f"This is placeholder narration because no OPENAI_API_KEY is set yet. "
            f"Add your key in .env to generate real scripts."
        )

    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
        json={
            "model": "gpt-4o-mini",
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Topic: {topic}"},
            ],
            "temperature": 0.9,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"].strip()


# --- To use Claude instead of OpenAI, replace the body of generate_script with:
#
# resp = requests.post(
#     "https://api.anthropic.com/v1/messages",
#     headers={
#         "x-api-key": settings.ANTHROPIC_API_KEY,
#         "anthropic-version": "2023-06-01",
#         "content-type": "application/json",
#     },
#     json={
#         "model": "claude-sonnet-4-6",
#         "max_tokens": 400,
#         "system": SYSTEM_PROMPT,
#         "messages": [{"role": "user", "content": f"Topic: {topic}"}],
#     },
#     timeout=60,
# )
# resp.raise_for_status()
# return resp.json()["content"][0]["text"].strip()
