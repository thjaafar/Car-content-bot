"""
Assembles the final vertical video: background clips + voiceover + burned-in captions.
Requires ffmpeg/ffprobe installed on the host (see README).
"""
import json
import os
import subprocess
from app.config import settings

TARGET_W, TARGET_H = 1080, 1920  # TikTok vertical


def _run(cmd: list[str]):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\n{result.stderr}")
    return result


def _audio_duration(path: str) -> float:
    if not path or not os.path.exists(path) or os.path.getsize(path) == 0:
        return 30.0  # fallback length when no real voiceover exists yet
    out = subprocess.run(
        ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", path],
        capture_output=True, text=True,
    )
    info = json.loads(out.stdout or "{}")
    return float(info.get("format", {}).get("duration", 30.0))


def _build_caption_filter(script: str, duration: float) -> str:
    """Splits the script into short chunks and times them evenly across the video."""
    words = script.split()
    chunk_size = 4
    chunks = [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]
    if not chunks:
        return ""

    per_chunk = duration / len(chunks)
    filters = []
    for i, chunk in enumerate(chunks):
        start = i * per_chunk
        end = start + per_chunk
        safe_text = chunk.replace("'", "").replace(":", "").replace('"', "")
        filters.append(
            f"drawtext=text='{safe_text}':fontcolor=white:fontsize=64:"
            f"font='DejaVu Sans Bold':borderw=4:bordercolor=black:"
            f"x=(w-text_w)/2:y=h*0.75:enable='between(t,{start:.2f},{end:.2f})'"
        )
    return ",".join(filters)


def assemble_video(job_id: str, script: str, audio_path: str, clip_paths: list[str]) -> str:
    os.makedirs(settings.VIDEOS_DIR, exist_ok=True)
    out_path = os.path.join(settings.VIDEOS_DIR, f"{job_id}.mp4")
    duration = _audio_duration(audio_path)

    if not clip_paths:
        # No footage yet (no PEXELS_API_KEY set) - render captions over a plain
        # background so the pipeline still produces a reviewable file.
        bg = f"color=c=0x1a1a1a:s={TARGET_W}x{TARGET_H}:d={duration}"
        caption_filter = _build_caption_filter(script, duration)
        vf = caption_filter if caption_filter else "null"
        cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i", bg, "-vf", vf,
               "-c:v", "libx264", "-t", str(duration), "-pix_fmt", "yuv420p"]
        if audio_path and os.path.exists(audio_path) and os.path.getsize(audio_path) > 0:
            cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i", bg, "-i", audio_path,
                   "-vf", vf, "-c:v", "libx264", "-c:a", "aac", "-shortest",
                   "-pix_fmt", "yuv420p"]
        cmd.append(out_path)
        _run(cmd)
        return out_path

    # Concatenate clips (scaled/cropped to fill vertical frame), then add audio + captions
    concat_list_path = os.path.join(settings.VIDEOS_DIR, f"{job_id}_concat.txt")
    scaled_dir = os.path.join(settings.VIDEOS_DIR, f"{job_id}_scaled")
    os.makedirs(scaled_dir, exist_ok=True)

    scaled_paths = []
    for i, clip in enumerate(clip_paths):
        scaled_path = os.path.join(scaled_dir, f"{i}.mp4")
        _run([
            "ffmpeg", "-y", "-i", clip,
            "-vf", f"scale={TARGET_W}:{TARGET_H}:force_original_aspect_ratio=increase,"
                   f"crop={TARGET_W}:{TARGET_H}",
            "-an", scaled_path,
        ])
        scaled_paths.append(scaled_path)

    with open(concat_list_path, "w") as f:
        for p in scaled_paths:
            f.write(f"file '{p}'\n")

    combined_path = os.path.join(settings.VIDEOS_DIR, f"{job_id}_combined.mp4")
    _run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_list_path,
          "-c", "copy", combined_path])

    caption_filter = _build_caption_filter(script, duration)
    vf = caption_filter if caption_filter else "null"
    cmd = ["ffmpeg", "-y", "-i", combined_path]
    if audio_path and os.path.exists(audio_path) and os.path.getsize(audio_path) > 0:
        cmd += ["-i", audio_path, "-vf", vf, "-c:v", "libx264", "-c:a", "aac",
                "-t", str(duration), "-shortest", "-pix_fmt", "yuv420p"]
    else:
        cmd += ["-vf", vf, "-c:v", "libx264", "-t", str(duration), "-pix_fmt", "yuv420p"]
    cmd.append(out_path)
    _run(cmd)
    return out_path
