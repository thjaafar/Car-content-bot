"""
Sources video clips for a job: a mix of real stock car footage (Pexels)
and AI-generated clips (Runway/Luma - stubbed, see note below).
"""
import os
import requests
from app.config import settings

PEXELS_SEARCH_URL = "https://api.pexels.com/videos/search"


def fetch_stock_clips(query: str, job_id: str, count: int = 2) -> list[str]:
    """Downloads `count` short stock clips matching `query` from Pexels."""
    os.makedirs(settings.CLIPS_DIR, exist_ok=True)
    paths = []

    if not settings.PEXELS_API_KEY:
        return paths  # no key yet - skip, assemble.py handles missing clips

    resp = requests.get(
        PEXELS_SEARCH_URL,
        headers={"Authorization": settings.PEXELS_API_KEY},
        params={"query": query, "per_page": count, "orientation": "portrait"},
        timeout=30,
    )
    resp.raise_for_status()
    videos = resp.json().get("videos", [])

    for i, video in enumerate(videos[:count]):
        # pick the highest-res portrait file available
        files = sorted(video.get("video_files", []), key=lambda f: f.get("width", 0), reverse=True)
        if not files:
            continue
        file_url = files[0]["link"]
        clip_path = os.path.join(settings.CLIPS_DIR, f"{job_id}_{i}.mp4")
        with requests.get(file_url, stream=True, timeout=60) as r:
            r.raise_for_status()
            with open(clip_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
        paths.append(clip_path)

    return paths


def fetch_ai_clips(prompt: str, job_id: str, count: int = 1) -> list[str]:
    """
    Generates AI video clips (e.g. via Runway's API).

    STUB: Runway/Luma's generation APIs change often and involve an async
    job-submit + poll flow. Rather than hardcode endpoints that may be stale,
    wire this up against whichever provider you land on:
      - Runway: https://docs.dev.runwayml.com
      - Luma:   https://docs.lumalabs.ai
    The shape is generally: submit a prompt -> poll for job completion ->
    download the resulting mp4 into settings.CLIPS_DIR, same as fetch_stock_clips.
    Returning [] here just means assemble.py falls back to stock-only.
    """
    if not settings.RUNWAY_API_KEY:
        return []
    # TODO: implement once you've picked and signed up for a provider.
    return []


def gather_visuals(topic: str, job_id: str) -> list[str]:
    """Mix of AI clips + stock footage, per user preference."""
    clips = []
    clips += fetch_ai_clips(topic, job_id, count=1)
    clips += fetch_stock_clips(topic, job_id, count=3)
    return clips
