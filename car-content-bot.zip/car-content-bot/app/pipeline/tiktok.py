"""
Posts a finished video to TikTok via the Content Posting API (Direct Post).

Until your app passes TikTok's audit, posts are restricted to SELF_ONLY
(private) visibility - see README for the audit process. This module still
uses the real Direct Post flow so switching to public just means changing
privacy_level once you're approved.

Docs: https://developers.tiktok.com/doc/content-posting-api-get-started-overview
"""
import os
import requests
from app.config import settings

API_BASE = "https://open.tiktokapis.com/v2"


def _headers():
    return {
        "Authorization": f"Bearer {settings.TIKTOK_ACCESS_TOKEN}",
        "Content-Type": "application/json; charset=UTF-8",
    }


def get_creator_info() -> dict:
    """Required before every post - tells you privacy options, max duration, etc."""
    resp = requests.post(f"{API_BASE}/post/publish/creator_info/query/",
                          headers=_headers(), timeout=30)
    resp.raise_for_status()
    return resp.json()


def post_video(video_path: str, caption: str, privacy_level: str = "SELF_ONLY") -> str:
    """
    Uploads and publishes a local video file. Returns TikTok's publish_id,
    which you poll via check_status().
    """
    if not settings.TIKTOK_ACCESS_TOKEN:
        raise RuntimeError(
            "No TIKTOK_ACCESS_TOKEN set. You need to complete TikTok's OAuth "
            "flow once to get a per-account access token - see README."
        )

    file_size = os.path.getsize(video_path)

    init_resp = requests.post(
        f"{API_BASE}/post/publish/video/init/",
        headers=_headers(),
        json={
            "post_info": {
                "title": caption,
                "privacy_level": privacy_level,
                "disable_duet": False,
                "disable_comment": False,
                "disable_stitch": False,
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": file_size,
                "chunk_size": file_size,
                "total_chunk_count": 1,
            },
        },
        timeout=30,
    )
    init_resp.raise_for_status()
    init_data = init_resp.json()["data"]
    upload_url = init_data["upload_url"]
    publish_id = init_data["publish_id"]

    with open(video_path, "rb") as f:
        video_bytes = f.read()

    upload_resp = requests.put(
        upload_url,
        headers={
            "Content-Type": "video/mp4",
            "Content-Range": f"bytes 0-{file_size - 1}/{file_size}",
        },
        data=video_bytes,
        timeout=120,
    )
    upload_resp.raise_for_status()

    return publish_id


def check_status(publish_id: str) -> dict:
    resp = requests.post(
        f"{API_BASE}/post/publish/status/fetch/",
        headers=_headers(),
        json={"publish_id": publish_id},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()
