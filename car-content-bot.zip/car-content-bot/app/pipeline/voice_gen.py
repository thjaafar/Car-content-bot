"""
Turns a script into an MP3 voiceover using ElevenLabs.
"""
import os
import requests
from app.config import settings


def generate_voice(script: str, job_id: str) -> str:
    out_path = os.path.join(settings.AUDIO_DIR, f"{job_id}.mp3")
    os.makedirs(settings.AUDIO_DIR, exist_ok=True)

    if not settings.ELEVENLABS_API_KEY or not settings.ELEVENLABS_VOICE_ID:
        # Silent stub file so the pipeline can still run without keys.
        # Replace with a real key to get actual narration.
        with open(out_path, "wb") as f:
            f.write(b"")
        return out_path

    voice_id = settings.ELEVENLABS_VOICE_ID
    resp = requests.post(
        f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
        headers={
            "xi-api-key": settings.ELEVENLABS_API_KEY,
            "Content-Type": "application/json",
        },
        json={
            "text": script,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {"stability": 0.4, "similarity_boost": 0.8},
        },
        timeout=120,
    )
    resp.raise_for_status()
    with open(out_path, "wb") as f:
        f.write(resp.content)
    return out_path
