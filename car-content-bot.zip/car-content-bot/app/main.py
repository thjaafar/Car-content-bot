import os
import traceback

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app import storage
from app.config import settings
from app.pipeline import script_gen, voice_gen, visuals, assemble, tiktok

app = FastAPI(title="Car Content Bot")

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")


class NewJobRequest(BaseModel):
    topic: str


class PostRequest(BaseModel):
    caption: str = ""
    privacy_level: str = "SELF_ONLY"


def run_pipeline(job_id: str):
    """Runs script -> voice -> visuals -> assembly. Called in the background."""
    try:
        job = storage.get_job(job_id)
        topic = job["topic"]

        storage.update_job(job_id, status="scripting")
        script = script_gen.generate_script(topic)
        storage.update_job(job_id, script=script, status="voicing")

        audio_path = voice_gen.generate_voice(script, job_id)
        storage.update_job(job_id, audio_path=audio_path, status="visuals")

        clip_paths = visuals.gather_visuals(topic, job_id)
        storage.update_job(job_id, clip_paths=clip_paths, status="assembling")

        video_path = assemble.assemble_video(job_id, script, audio_path, clip_paths)
        storage.update_job(job_id, video_path=video_path, status="ready")
    except Exception as e:
        storage.update_job(job_id, status="failed", error=f"{e}\n{traceback.format_exc()}")


@app.post("/api/jobs")
def create_job(req: NewJobRequest, background_tasks: BackgroundTasks):
    job = storage.create_job(req.topic)
    background_tasks.add_task(run_pipeline, job["id"])
    return job


@app.get("/api/jobs")
def list_jobs():
    return storage.list_jobs()


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job = storage.get_job(job_id)
    if not job:
        raise HTTPException(404, "job not found")
    return job


@app.get("/api/jobs/{job_id}/video")
def get_job_video(job_id: str):
    job = storage.get_job(job_id)
    if not job or not job.get("video_path") or not os.path.exists(job["video_path"]):
        raise HTTPException(404, "video not ready")
    return FileResponse(job["video_path"], media_type="video/mp4")


@app.post("/api/jobs/{job_id}/retry")
def retry_job(job_id: str, background_tasks: BackgroundTasks):
    job = storage.get_job(job_id)
    if not job:
        raise HTTPException(404, "job not found")
    storage.update_job(job_id, status="queued", error=None)
    background_tasks.add_task(run_pipeline, job_id)
    return storage.get_job(job_id)


@app.delete("/api/jobs/{job_id}")
def delete_job(job_id: str):
    storage.delete_job(job_id)
    return {"deleted": job_id}


@app.post("/api/jobs/{job_id}/post")
def post_to_tiktok(job_id: str, req: PostRequest):
    job = storage.get_job(job_id)
    if not job or job["status"] != "ready":
        raise HTTPException(400, "video isn't ready yet")
    try:
        caption = req.caption or job["topic"]
        publish_id = tiktok.post_video(job["video_path"], caption, req.privacy_level)
        storage.update_job(job_id, status="posted", tiktok_publish_id=publish_id)
        return {"publish_id": publish_id}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/jobs/{job_id}/post-status")
def post_status(job_id: str):
    job = storage.get_job(job_id)
    if not job or not job.get("tiktok_publish_id"):
        raise HTTPException(400, "not posted yet")
    return tiktok.check_status(job["tiktok_publish_id"])


# Serve the dashboard
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
